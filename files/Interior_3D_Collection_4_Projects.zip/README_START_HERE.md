# 3D Interior Collection | 4 Original Projects

These are four distinct, original low-to-mid-poly 3D concept scenes created from scratch, inspired by the modern interior aesthetic of the reference image. The scene is geometric 3D content, not a flat image.

## Four projects

1. CLOTHING BOUTIQUE: fashion retail interior with product shelves, garment rails, hanging clothes, display islands, checkout and fitting bench.
2. MODERN LIVING ROOM: warm wood-and-linen residential lounge with sectional sofa, coffee tables, entertainment wall, window, shelving and lighting.
3. SERENE BEDROOM SUITE: warm minimalist suite with platform bed, layered bedding, fluted headboard, pendant lamps, wardrobe and vanity.
4. HOME HANGOUT LOUNGE: home entertainment room with a billiards table and balls, bar counter and stools, TV/gaming console and conversation seating.

## Files in each project

- `.glb` : Recommended for **Blender** (File > Import > glTF 2.0). Editable objects and vertex colors; can then Save As `.blend`.
- `.obj` + `.mtl` : Recommended for **3ds Max** (File > Import) and other DCC tools. Keep OBJ and MTL together to retain assigned materials.
- `.dae` : COLLADA interchange, designed for **SketchUp** (File > Import > COLLADA) and other importers, subject to your version's capabilities.
- `PREVIEW_*.png` : camera view preview. Rendered from the actual meshes.
- `model_info.json` : size/objects/materials metadata.

## Notes

- The pack contains interchange files, NOT native `.max`, `.blend`, or `.skp` files. To create native projects, import into the named application and save as its native format.
- Units: meters. Coordinate system: Z axis up. Each project is a complete furnished concept space, with back and left walls intentionally shown and two sides open for viewing.
- All geometry and concept arrangements authored for this pack; does not include original/commercial CAD assets or high-resolution photorealistic textures.
- Materials are **simplified color materials**, with geometry designed to remain customizable. Some importers may require refreshing color assignments or axis rotation.
- Render previews are indicative concept visualization, not photographic renders.
- Furniture/object meshes are individually named; scene is suitable for rearranging, lighting, textures, and further architectural detailing.
